package com.virtusa.banking.customerms.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.customerms.models.Customer;
import com.virtusa.banking.customerms.repositories.CustomerRepository;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.bulkhead.annotation.Bulkhead.Type;
//import org.eclipse.microprofile.faulttolerance.Bulkhead;


@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	
	//insert the customer
	public Customer saveCustomer(Customer customer)
	{
		return this.customerRepo.save(customer);
	}
	
	//findall
	public List<Customer> getAllCustomers()
	{
		return this.customerRepo.findAll();
	}
	
	//select where by customerId
	 @Bulkhead(name = "getCustomerByIdService", fallbackMethod = "getFallbackgetCustomerById", type = Type.SEMAPHORE)
	// maximum 5 concurrent requests allowed
	//@Bulkhead(5)
	public Customer getCustomerById(long customerId)
	{
		/*
		 * try { Thread.sleep(3000); } catch (InterruptedException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
		return this.customerRepo.findById(customerId).orElse(null);
	}
	 public Customer getFallbackgetCustomerById(long customerId, Exception e) {
	        System.out.println("Falling back : " +customerId);
	        return new Customer();
	    }

	//delete the customer
	
	//select where by customerId
		public void deleteCustomerById(long customerId)
		{
		     this.customerRepo.deleteById(customerId);
		}
	
		//update the customer
		public Customer updateCustomer(Customer customer)
		{
			return this.customerRepo.save(customer);
		}

}
