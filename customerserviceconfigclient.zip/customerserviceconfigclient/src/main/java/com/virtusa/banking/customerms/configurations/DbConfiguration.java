package com.virtusa.banking.customerms.configurations;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DbConfiguration {
	//virtusa-banking.properties
		@Value("${db_url}")
		private String url;
		@Value("${db_username}")
		private String userName;
		@Value("${db_password}")
		private String password;
	//config-server-client-development.properties
		@Value("${serviceUrl}")
		private String serviceUrl;
		
		
		@Bean		
		public DataSource getInstance()
		{
			System.out.println("Service Url"+serviceUrl);
			DataSourceBuilder builder= DataSourceBuilder.create();
			builder.url(url);
			builder.username(userName);
			builder.password(password);
			return builder.build();		
		}

}
