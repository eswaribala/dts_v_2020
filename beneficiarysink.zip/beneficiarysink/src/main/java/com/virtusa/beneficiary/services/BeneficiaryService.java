package com.virtusa.beneficiary.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.beneficiary.models.Beneficiary;
import com.virtusa.beneficiary.repositories.BeneficiaryRepository;

@Service
public class BeneficiaryService {
    @Autowired
	private BeneficiaryRepository repo;
    
    public Beneficiary addBeneficiary(Beneficiary beneficiary)
    {
    	return this.repo.insert(beneficiary);
    }
}
