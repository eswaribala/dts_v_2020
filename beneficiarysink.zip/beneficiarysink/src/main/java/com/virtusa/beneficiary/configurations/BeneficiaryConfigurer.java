package com.virtusa.beneficiary.configurations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.core.JsonParser;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.virtusa.beneficiary.models.Beneficiary;
import com.virtusa.beneficiary.services.BeneficiaryService;

@Configuration
@EnableBinding(Sink.class)
public class BeneficiaryConfigurer {
    @Autowired 
	private BeneficiaryService beneficiaryService;
	
	@StreamListener(Sink.INPUT)
	public void saveBeneficiary(String beneficiary) {
		JsonObject convertedObject = new Gson().fromJson(beneficiary, 
				JsonObject.class);
		Beneficiary obj=new Gson().fromJson(convertedObject,Beneficiary.class);
		this.beneficiaryService.addBeneficiary(obj);
	}
}
