package com.virtusa.beneficiary.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.virtusa.beneficiary.models.Beneficiary;

public interface BeneficiaryRepository extends MongoRepository<Beneficiary,Integer>{

}
