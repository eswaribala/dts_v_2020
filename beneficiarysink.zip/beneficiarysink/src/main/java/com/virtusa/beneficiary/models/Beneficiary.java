package com.virtusa.beneficiary.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Document
@Data
public class Beneficiary {

	@Id
	@JsonProperty("accountNo")
	private int accountNo;
	@JsonProperty("ifscCode")
	private String ifscCode;
	@JsonProperty("bankName")
	private String bankName;
	@JsonProperty("name")
	private String name;
}
