package com.virtusa.banking.appointment.models;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class Customer {
	@JsonProperty("customerId")
	private long customerId;
	@JsonProperty("customerName")
	private String customer_Name;
	@JsonProperty("dob")
	private LocalDate dob;
	@JsonProperty("email")
	private String email;
	@JsonProperty("mobileNo")
	private long mobileNo;
		

}
