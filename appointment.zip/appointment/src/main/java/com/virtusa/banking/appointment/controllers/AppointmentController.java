package com.virtusa.banking.appointment.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.virtusa.banking.appointment.models.Appointment;
import com.virtusa.banking.appointment.services.AppointmentService;
@RestController
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;
	
	//saving the Appointment details
	@CrossOrigin("*")
	@PostMapping("/addappointment")
	public @ResponseBody Appointment addAppointment(@RequestBody Appointment appointment)
	{
		return this.appointmentService.saveAppointment(appointment);
	}
	
	//retrieval 
	
	@CrossOrigin("*")
	@GetMapping("/getallappointments")
	public List<Appointment> findAllAppointments()
	{
		return this.appointmentService.getAllAppointments();
	}
	
	//retrieval  by id
	
		@CrossOrigin("*")
		@GetMapping("/getappointmentbyid/{appointmentId}")
		public Appointment findAppointmentById(@PathVariable("appointmentId") long appointmentId)
		{
			return this.appointmentService.getAppointmentById(appointmentId);
		}
		
		@CrossOrigin("*")
		@GetMapping("/getappointmencustomertbyid/{appointmentId}")
		public String findAppointmentCustomerById(@PathVariable("appointmentId") long appointmentId) throws JsonProcessingException
		{
			return this.appointmentService.getAppointmentCustomerById(appointmentId);
			
		}
		
		
		@CrossOrigin("*")
		@DeleteMapping("/deleteappointmentbyid/{id}")
		public boolean deleteAppointmentById(@PathVariable("id") long id)
		{
			this.appointmentService.deleteAppointmentById(id);
			boolean status=false;
			if(appointmentService.getAppointmentById(id)==null)
				status=true;
			return status;
		}
		
		
		@CrossOrigin("*")
		@PutMapping("/updateappointment")
		public @ResponseBody Appointment updateAppointment(@RequestBody Appointment appointment)
		{
			return appointmentService.updateAppointment(appointment);
		}
			
}
