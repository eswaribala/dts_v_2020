package com.virtusa.banking.virtusacqrsaxon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtusacqrsaxonApplicationTests {

	@Test
	void contextLoads() {
	}

}
