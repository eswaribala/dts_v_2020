package com.virtusa.banking.virtusacqrsaxon.services;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.axonframework.queryhandling.QueryHandler;
import org.axonframework.modelling.command.Repository;

import org.springframework.stereotype.Service;

import com.virtusa.banking.virtusacqrsaxon.aggregators.Theatre;
import com.virtusa.banking.virtusacqrsaxon.queries.GetTheatresQuery;

@Service
public class TheatreService {
	
	private final Repository<Theatre> theatreRepository;

	public TheatreService(Repository<Theatre> theatreRepository) {
		this.theatreRepository = theatreRepository;
	}

	@QueryHandler
	public Theatre getLibrary(GetTheatresQuery query) throws InterruptedException, ExecutionException {
		CompletableFuture<Theatre> future = new CompletableFuture<Theatre>();
		theatreRepository.load(""+query.getRegNo()).execute(future::complete);
		return future.get();
	}



}
