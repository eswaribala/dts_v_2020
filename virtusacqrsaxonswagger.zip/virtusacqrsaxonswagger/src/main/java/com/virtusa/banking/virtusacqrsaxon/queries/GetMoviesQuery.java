package com.virtusa.banking.virtusacqrsaxon.queries;

import lombok.Data;

@Data
public class GetMoviesQuery {

	private final Integer regNo;

}
