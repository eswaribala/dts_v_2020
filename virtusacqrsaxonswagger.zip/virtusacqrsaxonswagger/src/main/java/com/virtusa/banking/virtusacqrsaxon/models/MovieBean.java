package com.virtusa.banking.virtusacqrsaxon.models;

import lombok.Data;

@Data
public class MovieBean {

	private int movieId;
	private String movieName;
	private String hero;
}
