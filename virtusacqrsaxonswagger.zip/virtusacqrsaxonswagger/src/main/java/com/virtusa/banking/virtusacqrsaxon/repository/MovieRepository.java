package com.virtusa.banking.virtusacqrsaxon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.banking.virtusacqrsaxon.models.MovieBean;
import com.virtusa.banking.virtusacqrsaxon.models.MovieEntity;

public interface MovieRepository extends JpaRepository<MovieEntity,Integer> {

	List<MovieEntity> findByRegNo(Integer regNo);

}
