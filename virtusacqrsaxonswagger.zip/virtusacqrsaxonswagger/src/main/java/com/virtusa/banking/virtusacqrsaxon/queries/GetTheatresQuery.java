package com.virtusa.banking.virtusacqrsaxon.queries;

import lombok.Data;

@Data
public class GetTheatresQuery {
	private final Integer regNo;

}
