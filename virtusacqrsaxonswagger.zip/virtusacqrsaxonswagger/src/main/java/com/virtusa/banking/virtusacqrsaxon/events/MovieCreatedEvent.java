package com.virtusa.banking.virtusacqrsaxon.events;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Data;

@Data
public class MovieCreatedEvent {

	@TargetAggregateIdentifier
	private final Integer regNo;
	private final int movieId;
	private final String movieName;
	private final String hero;

}
