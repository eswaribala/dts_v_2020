package com.virtusa.banking.virtusacqrsaxon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtusacqrsaxonSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusacqrsaxonSwaggerApplication.class, args);
	}

}
