package com.virtusa.banking.customerms.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.banking.customerms.models.Customer;
import com.virtusa.banking.customerms.repositories.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	
	//insert the customer
	public Customer saveCustomer(Customer customer)
	{
		return this.customerRepo.save(customer);
	}
	
	//findall
	public List<Customer> getAllCustomers()
	{
		return this.customerRepo.findAll();
	}
	
	//select where by customerId
	public Customer getCustomerById(long customerId)
	{
		return this.customerRepo.findById(customerId).orElse(null);
	}
	
	//delete the customer
	
	//select where by customerId
		public void deleteCustomerById(long customerId)
		{
		     this.customerRepo.deleteById(customerId);
		}
	
		//update the customer
		public Customer updateCustomer(Customer customer)
		{
			return this.customerRepo.save(customer);
		}

}
