package com.virtusa.beneficiary.configurations;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.support.MessageBuilder;
import com.virtusa.beneficiary.models.BeneficiaryBean;

@Configuration
@EnableBinding(Source.class)
public class SourceMessageConfigurer {
	
	@Bean
	@InboundChannelAdapter(value = Source.OUTPUT, poller = @Poller(fixedDelay = "1000", 
	maxMessagesPerPoll = "1"))
	public MessageSource<BeneficiaryBean> sendMessage()
	{
	   return ()->MessageBuilder.
			   withPayload(new BeneficiaryBean(28648324,"HSBC00034","HSBC","Parameswari")).build();
	}

}
