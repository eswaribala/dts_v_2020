package bulkheadexample;

import java.time.Duration;
import java.time.LocalTime;

import io.github.resilience4j.bulkhead.Bulkhead;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.bulkhead.BulkheadRegistry;



public class ServiceCallerClient {
	private Bulkhead bulkhead;
	 
	private ExternalConcurrentService externalConcurrentService = new ExternalConcurrentService();
 
	public ServiceCallerClient() {
		/*
		 * Create bulk head of 5 max concurrent calls with 2 seconds wait time for
		 * entering bulkhead
		 */
		BulkheadConfig config = BulkheadConfig.custom().maxConcurrentCalls(5).maxWaitDuration(Duration.ofMillis(5000))
				.build();
		BulkheadRegistry registry = BulkheadRegistry.of(config);
 
		bulkhead =  registry.bulkhead("externalConcurrentService");
	}
 
	public void callService() {
		// Wrap service call in bulkhead & call service.
		Runnable runnable = () -> externalConcurrentService.callService();
		(bulkhead).executeRunnable(runnable);
	}
}
 
class ExternalConcurrentService {
 
	public void callService() {
		try {
 
			// Mock processing time of 2 seconds.
			Thread.sleep(2000);
			System.out.println(LocalTime.now() + " Call processing finished = " + Thread.currentThread().getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
