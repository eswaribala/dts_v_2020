package bulkheadexample;

import java.time.LocalTime;
/**
 * 
 * @author Balasubramaniam *
 *we will call service client in 20 parallel threads which might mimic 20 
 *parallel users or 20 parallel executions.
 *
 *Service calls start:
At first you will see �Starting service call� for all 20 threads.
5 concurrent calls & other waiting:
Next 5 concurrent calls:
Wait time over for last 5 calls:
Then you will see that service-call-16 till service-call-20 ended up 
with io.github.resilience4j.bulkhead.BulkheadFullException 
because 5 second wait time for them was over.
 *
 *
 */
public class BulkheadBasics {
	public static void main(String[] args) throws InterruptedException {
		 
		ServiceCallerClient callerClient = new ServiceCallerClient();
 
		// Make 20 calls using service client mimicking 20 parallel users.
		for (int i = 0; i < 20; i++) {
			System.out.println(LocalTime.now() + " Starting service call = " + i);
			new Thread(() -> callerClient.callService(), "service-call-" + 
			(i + 1)).start();
			Thread.sleep(50);
		}
	}
}
