package com.virtusa.banking.hystrixdashboard.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.hystrixdashboard.services.CBCustomerHandler;

@RestController
public class CustomerCBController {

	@Autowired
	private CBCustomerHandler cbCustomerHandler;
	
	@GetMapping("/cbgetCustomerById/{customerId}")
	public String getCustomerById(@PathVariable("customerId") long customerId)
	{
		return this.cbCustomerHandler.handleRequest(customerId);
	}
	
}
