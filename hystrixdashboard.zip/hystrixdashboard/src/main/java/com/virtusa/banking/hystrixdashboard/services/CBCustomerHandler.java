package com.virtusa.banking.hystrixdashboard.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CBCustomerHandler {
	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "handleFailure")
	public String handleRequest(long customerId)
	{
		//inter service communication one to one
		return restTemplate.exchange("http://localhost:7070/getcustomerbyid/"+customerId, 
    			HttpMethod.GET,null, 
				new ParameterizedTypeReference<String>() {
        }).getBody();
	}
	
	public String handleFailure(long customerId)
	{
		//inter service communication one to one
		return restTemplate.exchange("http://localhost:7072/getcustomerbyid/"+customerId, 
    			HttpMethod.GET,null, 
				new ParameterizedTypeReference<String>() {
        }).getBody();
	}
}
