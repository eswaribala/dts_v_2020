import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewstatus',
  templateUrl: './viewstatus.component.html',
  styleUrls: ['./viewstatus.component.css']
})
export class ViewstatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
