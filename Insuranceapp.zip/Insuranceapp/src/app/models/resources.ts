export abstract class Resources {
  public static RightToLeft = 'ltr';

  public static DateIs: string = null;
  public static FirstName: string = null;
  public static LastName: string = null;
  public static Age: string = null;
  public static AgeRange: string = null;
  public static AgeRequired: string = null;
  public static Create: string = null;
  public static FirstNameLong: string = null;
  public static FirstNameRequired: string = null;
  public static LastNameLong: string = null;
  public static LastNameRequired: string = null;
}
