import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
@Component({
  selector: 'app-loss',
  templateUrl: './loss.component.html',
  styleUrls: ['./loss.component.css']
})
export class LossComponent implements OnInit {

  lostDate:FormControl;
  lossForm:FormGroup;
  constructor(private formBuilder:FormBuilder) {
   this.lostDate=new FormControl('',
     [Validators.required]);
   this.lossForm=formBuilder.group({
     lostDate:this.lostDate
   })


  }

  ngOnInit() {
  }

}
