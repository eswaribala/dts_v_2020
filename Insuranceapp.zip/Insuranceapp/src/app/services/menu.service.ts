import { Injectable } from '@angular/core';
import {MenuData} from "../models/menudata";
//singleton
@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() { }

  getMenuData(){
    return MenuData;
  }

}
