package com.virtusa.banking.virtusafeign.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.virtusa.banking.virtusafeign.services.CustomerServiceProxy;

@RestController
public class RibbonController {
	@Autowired  
 	private CustomerServiceProxy customerServiceProxy;
    
	@GetMapping(value="/getfeigncustomers")
	public String getFeignCustomerData()
	{
		
		ResponseEntity<String> responseEntity=customerServiceProxy.retrieveAssets();
		
		return responseEntity.getBody();
	}
	
	

}
