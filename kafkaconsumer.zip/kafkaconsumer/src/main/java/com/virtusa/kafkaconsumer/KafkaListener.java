package com.virtusa.kafkaconsumer;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.virtusa.kafkaconsumer.facades.BeneficiaryStreams;
import com.virtusa.kafkaconsumermodels.Beneficiary;

import lombok.extern.slf4j.Slf4j;

@EnableBinding(BeneficiaryStreams.class)
@Slf4j
public class KafkaListener {
	 @StreamListener(target = BeneficiaryStreams.INPUT)
	    public void handleBeneficiaries(@Payload Beneficiary beneficiary) {
	     log.info("invoked.....");   
		 log.info("Received beneficiary details: {}", beneficiary);
	    }
}
