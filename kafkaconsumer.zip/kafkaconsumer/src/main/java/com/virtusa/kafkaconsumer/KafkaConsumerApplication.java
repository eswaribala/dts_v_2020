package com.virtusa.kafkaconsumer;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Source;

import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.handler.annotation.Payload;

import com.virtusa.kafkaconsumer.facades.BeneficiaryStreams;
import com.virtusa.kafkaconsumermodels.Beneficiary;

import lombok.extern.slf4j.Slf4j;



@SpringBootApplication
@EnableBinding(BeneficiaryStreams.class)
@Slf4j
public class KafkaConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaConsumerApplication.class, args);
	}
	
	@StreamListener(target = BeneficiaryStreams.INPUT)
    public void handleGreetings(@Payload Beneficiary beneficiary) {
     log.info("invoked.....");   
	 log.info("Received beneficiary details: {}", beneficiary);
    }
}
	