package com.virtusa.banking.virtusagateway.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.banking.virtusagateway.domain.DynamicRoute;
import com.virtusa.banking.virtusagateway.security.ZuulRouteService;

import net.minidev.json.JSONObject;

@RestController
public class DynamicRouteController {
	@Autowired
	private ZuulRouteService zuulRouteService;
	@CrossOrigin("*")
	@PostMapping("/addroute")
	public @ResponseBody ResponseEntity<?> addDynamicRoute(@RequestBody DynamicRoute dynamicRoute)
	{
		this.zuulRouteService.addDynamicRouteInZuul(dynamicRoute);
	
		// JSONObject jsonObject=new JSONObject();
		//jsonObject.appendField("Message", "RouteCreaed");
		return ResponseEntity.ok(dynamicRoute);
	}
	@GetMapping("/getRoutes")
	public ResponseEntity<?> getAllZuulRoutes()
	{
		return ResponseEntity.ok(this.zuulRouteService.getAllRoutes());
	}
	
}
