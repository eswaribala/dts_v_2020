package com.virtusa.banking.virtusagateway.security;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.zuul.filters.ZuulProperties;
import org.springframework.cloud.netflix.zuul.filters.ZuulProperties.ZuulRoute;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.virtusa.banking.virtusagateway.domain.DynamicRoute;

@Service
public class ZuulRouteService {
	@Autowired
	private ZuulProperties zuulProperties;
	private static final String HTTP_PROTOCOL = "http://";
	public void addDynamicRouteInZuul(DynamicRoute dynamicRoute) {
		String url = createTargetURL(dynamicRoute);
		zuulProperties.getRoutes().put(dynamicRoute.getRequestURIUniqueKey(),
				new ZuulRoute(dynamicRoute.getRequestURIUniqueKey(), dynamicRoute.getRequestURI() + "/**",
						null, url, true, false, new HashSet<>()));
	}

	private String createTargetURL(DynamicRoute dynamicRoute) {
		StringBuilder sb = new StringBuilder(HTTP_PROTOCOL);
		sb.append(dynamicRoute.getTargetURLHost()).append(":").append(dynamicRoute.getTargetURLPort());
		if (StringUtils.isEmpty(dynamicRoute.getTargetURIPath())) {
			sb.append("");
		} else {
			sb.append(dynamicRoute.getTargetURIPath());
		}
		String url = sb.toString();
		return url;
	}
	
	
	public Map<String, ZuulRoute> getAllRoutes()
	{
		return this.zuulProperties.getRoutes();
	}
}
