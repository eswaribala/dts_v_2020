package com.virtusa.banking.virtusagateway.configurations;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PreFilter extends ZuulFilter{
	private static Logger log = LoggerFactory.getLogger(PreFilter.class);
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() {
		final RequestContext ctx = RequestContext.getCurrentContext();
		final HttpServletRequest request = ctx.getRequest();
		final String getHeader = request.getHeader("Authorization");
		
		final Enumeration<String> headers = request.getHeaderNames();
		
		while (headers.hasMoreElements()) {
			final String headerName = headers.nextElement();
			final String header = request.getHeader(headerName);
			
			System.out.println(headerName+ "=" +header);
		}
		
		log.trace(String.format("%s request to %s", request.getMethod(), request.getRequestURL().toString()));
		
		
	    return null;
	}

	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return "pre";
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

}
