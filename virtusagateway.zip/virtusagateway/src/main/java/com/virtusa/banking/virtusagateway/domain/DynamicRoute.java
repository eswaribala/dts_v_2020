package com.virtusa.banking.virtusagateway.domain;

import com.virtusa.banking.virtusagateway.controllers.AuthenticationRequest;
import com.virtusa.banking.virtusagateway.controllers.AuthenticationRequest.AuthenticationRequestBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DynamicRoute {
	
	public String requestURIUniqueKey;
	
	private String requestURI;
	
	private String targetURLHost;

	private int targetURLPort;
	
	private String targetURIPath;
}
