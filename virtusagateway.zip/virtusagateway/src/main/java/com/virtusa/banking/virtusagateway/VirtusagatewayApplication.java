package com.virtusa.banking.virtusagateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.virtusa.banking.virtusagateway.configurations.ErrorFilter;
import com.virtusa.banking.virtusagateway.configurations.PostFilter;
import com.virtusa.banking.virtusagateway.configurations.PreFilter;
import com.virtusa.banking.virtusagateway.configurations.RouterFilter;

@SpringBootApplication
@EnableDiscoveryClient
@EnableZuulProxy
public class VirtusagatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusagatewayApplication.class, args);
	}
	@Bean
	public PreFilter preFilter() {
		return new PreFilter();
	}
	@Bean
	public PostFilter postFilter() {
		return new PostFilter();
	}
	@Bean
	public ErrorFilter errorFilter() {
		return new ErrorFilter();
	}
	@Bean
	public RouterFilter routeFilter() {
		return new RouterFilter();
	}
	
	@Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }


}
