package com.virtusa.banking.virtusagateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtusagatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
