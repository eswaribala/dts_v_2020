package com.virtusa.beneficiary.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BeneficiaryBean {
    @JsonProperty("accountNo")   
	private long accountNo;
    @JsonProperty("ifscCode")   
	private String ifscCode;
    @JsonProperty("bankName")   
	private String bankName;
    @JsonProperty("name")   
	private String name;
}
