package com.virtusa.beneficiary.configurations;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;

import com.google.gson.Gson;
import com.virtusa.beneficiary.models.BeneficiaryBean;

@EnableBinding(Processor.class)

//no configuration
public class MessageProcessorConfigurer {

	//no bean
	@ServiceActivator(inputChannel = Processor.INPUT, outputChannel = Processor.OUTPUT)
	public String transformMessage(BeneficiaryBean beneficiaryBean)
	{
		/*	
		Map<String,String> obj=new HashMap<String,String>();
		obj.put("accountNo", String.valueOf(beneficiaryBean.getAccountNo()));
		obj.put("ifscCode",beneficiaryBean.getIfscCode());
		obj.put("bankName",beneficiaryBean.getBankName());
		obj.put("name",beneficiaryBean.getName());
		return JSONValue.toJSONString(obj);
		*/
		return new Gson().toJson(beneficiaryBean);
		
	}

	
}
