package com.virtusa.banking.virtusaribbon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.ribbon.RibbonClient;

import com.virtusa.banking.virtusaribbon.configurations.RibbonConfiguration;

@SpringBootApplication
@RibbonClient(name = "VIRTUSA-RIBBON", configuration = RibbonConfiguration.class)

public class VirtusaribbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusaribbonApplication.class, args);
	}

}
