package com.ericsson.customerserviceapp;
/*
 * import org.springframework.test.context.junit4.SpringRunner;
 * 
 * import static org.junit.jupiter.api.Assertions.assertEquals;
 * 
 * import java.time.LocalDate;
 * 
 * import org.junit.jupiter.api.BeforeAll; import org.junit.jupiter.api.Test;
 * import org.junit.jupiter.params.ParameterizedTest; import
 * org.junit.jupiter.params.provider.CsvFileSource; import
 * org.junit.runner.RunWith; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.autoconfigure.orm.jpa.
 * AutoConfigureTestEntityManager; import
 * org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager; import
 * org.springframework.boot.test.context.SpringBootTest; import
 * org.springframework.transaction.annotation.Transactional;
 * 
 * import com.ericsson.customerserviceapp.models.Customer; import
 * com.ericsson.customerserviceapp.repositories.CustomerRepository;
 * 
 * @RunWith(SpringRunner.class)
 * 
 * @SpringBootTest
 * 
 * @AutoConfigureTestEntityManager
 * 
 * @Transactional class CustomerserviceappApplicationTests {
 * 
 * @Autowired private TestEntityManager entityManager;
 * 
 * @Autowired private CustomerRepository customerRepository; private static
 * Customer customer =new Customer();
 * 
 * @BeforeAll static void init() { customer.setAdharCardNo(5667834);
 * customer.setFirstName("viki"); customer.setLastName("bala");
 * customer.setEmail("viki@gmail.com"); customer.setMobileNo(9999999997L);
 * customer.setDob(LocalDate.of(1987, 12, 2)); }
 * 
 * @Test void testCustomerObjectPersistence() { entityManager.persist(customer);
 * entityManager.flush(); Customer customerObj=
 * customerRepository.findById(customer.getAdharCardNo()).orElse(null);
 * assertEquals(customerObj.getAdharCardNo(), customer.getAdharCardNo());
 * 
 * }
 * 
 * 
 * @ParameterizedTest
 * 
 * @CsvFileSource(resources = "/customers.csv", numLinesToSkip = 1) void
 * testParameterizedCustomerObjectPersistence(long adharCardNo,String
 * firstName,String lastName,String email,long mobileNo, String dob) { Customer
 * customerInstance=new Customer();
 * customerInstance.setAdharCardNo(adharCardNo);
 * customerInstance.setFirstName(firstName);
 * customerInstance.setLastName(lastName); customerInstance.setEmail(email);
 * customerInstance.setMobileNo(mobileNo);
 * customerInstance.setDob(LocalDate.parse(dob));
 * entityManager.persist(customerInstance); entityManager.flush(); Customer
 * customerObj=
 * customerRepository.findById(customerInstance.getAdharCardNo()).orElse(null);
 * assertEquals(customerObj.getAdharCardNo(),
 * customerInstance.getAdharCardNo());
 * 
 * }
 * 
 * 
 * 
 * }
 */