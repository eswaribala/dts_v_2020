package com.virtusa.banking.virtusarediscache.repositories;

import org.springframework.data.repository.CrudRepository;

import com.virtusa.banking.virtusarediscache.models.DynamicRoute;

public interface RedisRepository extends CrudRepository<DynamicRoute,String>{

}
