package com.virtusa.kafkaproducer.facades;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

public interface BeneficiaryStreams {
	
    String OUTPUT = "beneficiary-out";
   
    @Output(OUTPUT)
    MessageChannel outboundBeneficiary();

}
