package com.virtusa.kafkaproducer.services;

import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.virtusa.kafkaproducer.facades.BeneficiaryStreams;
import com.virtusa.kafkaproducer.models.Beneficiary;


import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BeneficiaryService {
	 private final BeneficiaryStreams beneficiaryStreams;
	    public BeneficiaryService(BeneficiaryStreams beneficiaryStreams) {
	        this.beneficiaryStreams = beneficiaryStreams;
	    }
	    public boolean addBeneficiaryInfo(Beneficiary beneficiary) {
	        log.info("Sending Beneficiary {}", beneficiary);
	        MessageChannel messageChannel = beneficiaryStreams.outboundBeneficiary();
	       return  messageChannel.send(MessageBuilder
	                .withPayload(beneficiary)
	                .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON)
	                .build());
	    }
}
